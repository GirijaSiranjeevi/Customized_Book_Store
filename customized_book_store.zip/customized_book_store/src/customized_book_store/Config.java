/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package customized_book_store;
import java.sql.*;


/**
 *
 * @author GIRIJA
 */
public class Config {
static Connection con=null;

public static Connection getConnection()
{
try
{
Class.forName("com.mysql.cj.jdbc.Driver");
con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/customized_book_store","root","root");
}
catch(Exception e)
{
    e.printStackTrace();
    
}
return con;
}
    
}
